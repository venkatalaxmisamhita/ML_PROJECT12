"""Flask API + static frontend for the Cricket Performance Predictor.

Run:  python train_models.py   (once)
      python app.py            -> http://127.0.0.1:5000
"""
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from flask import Flask, jsonify, request, send_from_directory

from features import CAT_FEATURES, NUM_FEATURES, next_innings_features

ROOT = Path(__file__).parent
M = ROOT / "model"
bundle = joblib.load(M / "models.joblib")
PIPES, HELPERS, H_IN = bundle["pipes"], bundle["helpers"], bundle["helper_inputs"]
MEDIANS, MATCHTYPES = bundle["medians"], bundle["matchtypes"]
META = json.load(open(M / "meta.json"))
PLAYERS = pd.read_pickle(M / "players.pkl")
INNINGS = pd.read_pickle(M / "innings.pkl")
BAND = META["band"]

app = Flask(__name__, static_folder="static", static_url_path="/static")


def predict_all(feat: dict, matchtype: str) -> dict:
    row = pd.DataFrame([{**{k: feat[k] for k in NUM_FEATURES}, "matchtype": matchtype}])
    out = {}
    for key, pipe in PIPES.items():
        out[key] = max(0.0, float(pipe.predict(row)[0]))      # runs cannot be negative
    return out


def explain(feat: dict, matchtype: str, top=6):
    """Ridge: contribution of each feature = standardised value x coefficient (in runs vs. an average innings)."""
    pipe = PIPES["ridge"]
    row = pd.DataFrame([{**{k: feat[k] for k in NUM_FEATURES}, "matchtype": matchtype}])
    scaler = pipe.named_steps["pre"].named_transformers_["num"]
    z = scaler.transform(row[NUM_FEATURES])[0]
    coefs = pipe.named_steps["model"].coef_[: len(NUM_FEATURES)]
    contrib = [{"feature": f, "value": float(feat[f]), "impact": float(c * v)}
               for f, c, v in zip(NUM_FEATURES, coefs, z)]
    contrib.sort(key=lambda d: abs(d["impact"]), reverse=True)
    return contrib[:top]


def package(feat, matchtype, extra):
    preds = predict_all(feat, matchtype)
    best = preds["ridge"]
    return {
        "predictions": {k: {"runs": round(v, 1), "label": META["metrics"][k]["label"]} for k, v in preds.items()},
        "headline": round(best, 1),
        "range": [round(max(0.0, best + BAND["p10"]), 1), round(best + BAND["p90"], 1)],
        "drivers": explain(feat, matchtype),
        "features": {k: round(float(v), 2) for k, v in feat.items()},
        **extra,
    }


@app.get("/")
def index():
    return send_from_directory("static", "index.html")


@app.get("/api/meta")
def meta():
    return jsonify({**META, "matchtypes": MATCHTYPES, "features": NUM_FEATURES})


@app.get("/api/players")
def players():
    q = request.args.get("q", "").strip().lower()
    if len(q) < 2:
        return jsonify([])
    hit = PLAYERS[PLAYERS["name"].str.lower().str.contains(q, regex=False)]
    hit = hit.sort_values("innings", ascending=False).head(12)
    return jsonify([{"id": int(r.player_id), "name": r.name, "innings": int(r.innings),
                     "role": r.role, "career_avg": round(float(r.career_avg), 1)} for r in hit.itertuples()])


@app.get("/api/player/<int:pid>")
def player(pid):
    g = INNINGS[INNINGS["player_id"] == pid].sort_values(["start_date", "match_id", "id"])
    if g.empty:
        return jsonify({"error": "Player not found"}), 404
    recent = g.tail(15)
    return jsonify({
        "id": pid, "name": g["name_x"].iloc[-1], "innings": int(len(g)),
        "career_avg": round(float(g["runs_x"].mean()), 1),
        "last5_avg": round(float(g["runs_x"].tail(5).mean()), 1),
        "high": int(g["runs_x"].max()),
        "common_format": g["matchtype"].mode().iat[0],
        "avg_order": round(float(g["order"].mean()), 1),
        "recent": [{"runs": int(r.runs_x), "balls": int(r.balls), "fmt": r.matchtype,
                    "date": r.start_date.strftime("%Y-%m-%d"), "out": r.how_out,
                    "match": r.name_y or ""} for r in recent.itertuples()],
    })


@app.post("/api/predict")
def predict():
    d = request.get_json(force=True)
    mt = d.get("matchtype", "odi")
    if mt not in MATCHTYPES:
        return jsonify({"error": f"matchtype must be one of {MATCHTYPES}"}), 400

    if d.get("mode") == "player":
        g = INNINGS[INNINGS["player_id"] == int(d["player_id"])]
        if g.empty:
            return jsonify({"error": "Player not found"}), 404
        feat = next_innings_features(g)
        return jsonify(package(feat, mt, {"mode": "player"}))

    # manual mode: user supplies previous scores (oldest -> newest) + a few context values
    try:
        scores = [float(x) for x in d.get("scores", [])]
    except (TypeError, ValueError):
        return jsonify({"error": "Scores must be numbers"}), 400
    if not 1 <= len(scores) <= 50 or any(s < 0 or s > 500 for s in scores):
        return jsonify({"error": "Enter between 1 and 50 previous scores, each between 0 and 500."}), 400

    car = float(d.get("career_avg") or np.mean(scores))
    n_inn = float(d.get("innings") or max(len(scores), 1))
    order = float(d.get("order") or 4)
    sr = float(d.get("strike_rate") or MEDIANS["car_SR"])
    feat = {"n_innings": n_inn, "car_runs": car, "car_SR": sr, "car_order": order,
            "last3_runs": float(np.mean(scores[-3:])), "last5_runs": float(np.mean(scores[-5:])),
            "days_gap": MEDIANS["days_gap"]}
    base = pd.DataFrame([{k: feat[k] for k in H_IN}])
    for tgt, mdl in HELPERS.items():
        feat[tgt] = max(0.0, float(mdl.predict(base)[0]))
    feat["car_max"] = max(feat["car_max"], max(scores))
    return jsonify(package(feat, mt, {"mode": "manual"}))


if __name__ == "__main__":
    app.run(debug=True, port=5000)
