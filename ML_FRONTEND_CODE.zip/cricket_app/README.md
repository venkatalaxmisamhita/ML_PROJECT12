# Cricket performance predictor

1. `pip install -r requirements.txt`
2. Put `bat.csv` from ML_DATASET in `data/` (from ML_DATASET.zip)
3. `python train_models.py`   # trains OLS / Ridge / Lasso / ElasticNet, writes model/
4. `python app.py`            # open http://127.0.0.1:5000

Files: `features.py` (cleaning + lagged features), `train_models.py`, `app.py` (Flask API), `static/index.html` (frontend).
