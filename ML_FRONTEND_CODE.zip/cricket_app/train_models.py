"""Train OLS / Ridge / Lasso / ElasticNet on the cleaned, lag-engineered dataset and save everything the app needs."""
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.linear_model import ElasticNet, Lasso, LinearRegression, Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from features import CAT_FEATURES, NUM_FEATURES, TARGET, build_training_frame, clean

ROOT = Path(__file__).parent
OUT = ROOT / "model"
OUT.mkdir(exist_ok=True)

raw = pd.read_csv(ROOT / "data" / "bat.csv")
df = clean(raw)
frame = build_training_frame(df)
print(f"Cleaned innings: {len(df):,} | modelling rows: {len(frame):,}")

X, y = frame[NUM_FEATURES + CAT_FEATURES], frame[TARGET]
X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.20, random_state=42)
print(f"Train {len(X_tr):,} | Test {len(X_te):,}")


def make_pipe(est):
    pre = ColumnTransformer([
        ("num", StandardScaler(), NUM_FEATURES),
        ("cat", OneHotEncoder(handle_unknown="ignore"), CAT_FEATURES),
    ])
    return Pipeline([("pre", pre), ("model", est)])


MODELS = {
    "ols": ("Linear Regression (OLS)", LinearRegression()),
    "ridge": ("Ridge (alpha=1.0)", Ridge(alpha=1.0)),
    "lasso": ("Lasso (alpha=0.01)", Lasso(alpha=0.01, max_iter=20000)),
    "elasticnet": ("ElasticNet (alpha=0.01, l1=0.5)", ElasticNet(alpha=0.01, l1_ratio=0.5, max_iter=20000)),
}

metrics, pipes = {}, {}
for key, (label, est) in MODELS.items():
    pipe = make_pipe(est).fit(X_tr, y_tr)
    pred = pipe.predict(X_te)
    mse = mean_squared_error(y_te, pred)
    metrics[key] = {"label": label, "mae": mean_absolute_error(y_te, pred), "mse": mse,
                    "rmse": float(np.sqrt(mse)), "r2": r2_score(y_te, pred)}
    pipes[key] = pipe
    print(f"{label:34s} MAE {metrics[key]['mae']:.4f}  RMSE {metrics[key]['rmse']:.4f}  R2 {metrics[key]['r2']:.4f}")

# Honest uncertainty band: spread of Ridge residuals on unseen data
resid = y_te.values - pipes["ridge"].predict(X_te)
band = {"p10": float(np.percentile(resid, 10)), "p90": float(np.percentile(resid, 90))}

# Ridge coefficients (standardised) for the "what drove this prediction" view
names = list(pipes["ridge"].named_steps["pre"].get_feature_names_out())
coefs = dict(zip(names, pipes["ridge"].named_steps["model"].coef_.tolist()))

# Small helper models so manual mode can fill features the user did not type in
helpers = {}
base = ["car_runs", "car_order", "car_SR", "n_innings"]
for tgt in ["car_balls", "car_fours", "car_sixes", "car_max", "last5_balls", "last5_fours", "last5_sixes", "last5_SR"]:
    helpers[tgt] = LinearRegression().fit(frame[base], frame[tgt])

joblib.dump({"pipes": pipes, "helpers": helpers, "helper_inputs": base,
             "medians": frame[NUM_FEATURES].median().to_dict(),
             "matchtypes": sorted(frame["matchtype"].unique().tolist())}, OUT / "models.joblib")

# Player index (name, role, innings) + trimmed history for the UI
players = (df.groupby("player_id")
             .agg(name=("name_x", "last"), role=("playing_role", lambda s: s.mode().iat[0]),
                  innings=("runs_x", "size"), career_avg=("runs_x", "mean"),
                  last_date=("start_date", "max"))
             .reset_index())
players.to_pickle(OUT / "players.pkl")
df.to_pickle(OUT / "innings.pkl")

json.dump({"metrics": metrics, "band": band, "coefs": coefs,
           "n_train": len(X_tr), "n_test": len(X_te), "n_players": int(players.shape[0]),
           "target_mean": float(y.mean()), "target_median": float(y.median())},
          open(OUT / "meta.json", "w"), indent=2)
print("Saved model/ artefacts")
