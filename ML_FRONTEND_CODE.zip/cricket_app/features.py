"""Shared cleaning + feature engineering (used by training and by the API)."""
import html
import numpy as np
import pandas as pd

# 15 numeric pre-match predictors (all leakage-free: built only from innings BEFORE the target one)
NUM_FEATURES = [
    "n_innings", "car_runs", "car_SR", "car_balls", "car_order", "car_fours",
    "car_sixes", "car_max", "last3_runs", "last5_runs", "last5_SR",
    "last5_balls", "last5_fours", "last5_sixes", "days_gap",
]
CAT_FEATURES = ["matchtype"]
TARGET = "runs_x"


def clean(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df = df.drop(columns=[c for c in df.columns if c.startswith("Unnamed")], errors="ignore")
    df = df.drop(columns=["fall_of_wicket"], errors="ignore")          # 99.9% empty
    df["how_out"] = df["how_out"].fillna("unspecified").map(html.unescape)
    df["matchtype"] = df["matchtype"].fillna("unknown")
    df["playing_role"] = df["playing_role"].fillna("unspecified")
    df["start_date"] = pd.to_datetime(df["start_date"], utc=True).dt.tz_localize(None)
    df["strike_rate"] = np.where(df["balls"] > 0, df["runs_x"] / df["balls"].replace(0, np.nan) * 100, 0.0)
    df["strike_rate"] = df["strike_rate"].fillna(0.0)
    return df


def _grp_features(g: pd.DataFrame) -> pd.DataFrame:
    """Features for every innings of ONE player, shifted by 1 so the current innings never leaks."""
    g = g.sort_values(["start_date", "match_id", "id"]).copy()
    s = lambda col: g[col].shift(1)
    g["n_innings"] = np.arange(len(g))
    for name, col in [("car_runs", "runs_x"), ("car_SR", "strike_rate"), ("car_balls", "balls"),
                      ("car_order", "order"), ("car_fours", "fours"), ("car_sixes", "sixes")]:
        g[name] = s(col).expanding().mean()
    g["car_max"] = s("runs_x").expanding().max()
    g["last3_runs"] = s("runs_x").rolling(3, min_periods=1).mean()
    g["last5_runs"] = s("runs_x").rolling(5, min_periods=1).mean()
    g["last5_SR"] = s("strike_rate").rolling(5, min_periods=1).mean()
    g["last5_balls"] = s("balls").rolling(5, min_periods=1).mean()
    g["last5_fours"] = s("fours").rolling(5, min_periods=1).mean()
    g["last5_sixes"] = s("sixes").rolling(5, min_periods=1).mean()
    g["days_gap"] = g["start_date"].diff().dt.days
    return g


def build_training_frame(df: pd.DataFrame) -> pd.DataFrame:
    out = pd.concat([_grp_features(g) for _, g in df.groupby("player_id")], ignore_index=True)
    out = out[out["n_innings"] > 0].copy()          # first innings of each player has no history
    out["days_gap"] = out["days_gap"].fillna(0)
    return out.dropna(subset=NUM_FEATURES)


def next_innings_features(g: pd.DataFrame) -> dict:
    """Feature vector describing a player's form going INTO their next (unplayed) innings."""
    g = g.sort_values(["start_date", "match_id", "id"])
    last5 = g.tail(5)
    return {
        "n_innings": float(len(g)),
        "car_runs": g["runs_x"].mean(), "car_SR": g["strike_rate"].mean(),
        "car_balls": g["balls"].mean(), "car_order": g["order"].mean(),
        "car_fours": g["fours"].mean(), "car_sixes": g["sixes"].mean(),
        "car_max": float(g["runs_x"].max()),
        "last3_runs": g["runs_x"].tail(3).mean(), "last5_runs": last5["runs_x"].mean(),
        "last5_SR": last5["strike_rate"].mean(), "last5_balls": last5["balls"].mean(),
        "last5_fours": last5["fours"].mean(), "last5_sixes": last5["sixes"].mean(),
        "days_gap": 14.0,   # typical gap between matches; the next fixture date is unknown
    }
